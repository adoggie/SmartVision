---
title: "URI"
symbol_kind: "intro"
decl_name: "mg_uri.h"
items:
  - { name: mg_assemble_uri.md }
  - { name: mg_parse_uri.md }
---



