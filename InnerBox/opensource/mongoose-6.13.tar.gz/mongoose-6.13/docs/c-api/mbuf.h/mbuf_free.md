---
title: "mbuf_free()"
decl_name: "mbuf_free"
symbol_kind: "func"
signature: |
  void mbuf_free(struct mbuf *);
---

Frees the space allocated for the mbuffer and resets the mbuf structure. 

