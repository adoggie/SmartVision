---
title: "mg_fu_fname_fn"
decl_name: "mg_fu_fname_fn"
symbol_kind: "typedef"
signature: |
  typedef struct mg_str (*mg_fu_fname_fn)(struct mg_connection *nc,
                                          struct mg_str fname);
---

Callback prototype for `mg_file_upload_handler()`. 

